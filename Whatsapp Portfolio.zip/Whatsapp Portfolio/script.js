var audio = new Audio('assets/sentmessage.mp3');
var contactString = "<div class='social'> <a target='_blank' href='tel:+918555965759'> <div class='socialItem' id='call'><img class='socialItemI' src='images/phone.svg'/></div> </a> <a href='mailto:muggalla.rahul.02@proton.me'> <div class='socialItem'><img class='socialItemI' src='images/gmail.svg' alt=''></div> </a> <a target='_blank' href='https://github.com/rahulmuggalla'> <div class='socialItem'><img class='socialItemI' src='images/github.svg' alt=''></div> </a> <a target='_blank' href='https://wa.me/+918555965759'> <div class='socialItem'><img class='socialItemI' src='images/whatsapp.svg' alt=''></div> </a> <a target='_blank' href='https://t.me/mr_peculiar_02'> <div class='socialItem'><img class='socialItemI' src='images/telegram.svg' alt=''></div> </a> <a href='https://linkedin.com/in/muggalla-rahul' target='_blank' rel='noopener noreferrer'> <div class='socialItem'><img class='socialItemI' src='images/linkedin.svg' alt=''></div> </a> </div>";
var resumeString = "<img src='images/resumeThumbnail.png' class='resumeThumbnail'><div class='downloadSpace'><div class='pdfname'><img src='images/pdf.png'><label>Resume.pdf</label></div><a href='assets/Muggalla_Rahul_Resume.pdf' download='Muggalla_Rahul_Resume.pdf'><img class='download' src='images/downloadIcon.svg'></a></div>";
var addressString = "<div class='mapview'><iframe src='https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d7650.719594604235!2d80.64602408105974!3d16.507923644333964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1683828536073!5m2!1sen!2sin' class='map'></iframe></div><label class='add'><address><br>Vijayawada, Andhra Pradesh, INDIA - 520002</address>";
function startFunction() {
    setLastSeen();
    waitAndResponce("intro");
}

function setLastSeen() {
    var date = new Date();
    var lastSeen = document.getElementById("lastseen");
    lastSeen.innerText = "last seen today at " + date.getHours() + ":" + date.getMinutes()
}


function closeFullDP() {
    var x = document.getElementById("fullScreenDP");
    if (x.style.display === 'flex') {
        x.style.display = 'none';
    } else {
        x.style.display = 'flex';
    }
}

function openFullScreenDP() {
    var x = document.getElementById("fullScreenDP");
    if (x.style.display === 'flex') {
        x.style.display = 'none';
    } else {
        x.style.display = 'flex';
    }
}


function isEnter(event) {
    if (event.keyCode == 13) {
        sendMsg();
    }
}

function sendMsg() {
    var input = document.getElementById("inputMSG");
    var ti = input.value;
    if (input.value == "") {
        return;
    }
    var date = new Date();
    var myLI = document.createElement("li");
    var myDiv = document.createElement("div");
    var greendiv = document.createElement("div");
    var dateLabel = document.createElement("label");
    dateLabel.innerText = date.getHours() + ":" + date.getMinutes();
    myDiv.setAttribute("class", "sent");
    greendiv.setAttribute("class", "green");
    dateLabel.setAttribute("class", "dateLabel");
    greendiv.innerText = input.value;
    myDiv.appendChild(greendiv);
    myLI.appendChild(myDiv);
    greendiv.appendChild(dateLabel);
    document.getElementById("listUL").appendChild(myLI);
    var s = document.getElementById("chatting");
    s.scrollTop = s.scrollHeight;
    setTimeout(function () { waitAndResponce(ti) }, 1500);
    input.value = "";
    playSound();
}

function waitAndResponce(inputText) {
    var lastSeen = document.getElementById("lastseen");
    lastSeen.innerText = "Typing...";
    switch (inputText.toLowerCase().trim()) {
        case "intro":
            setTimeout(() => {
                sendTextMessage("Hi 👋🏻,<br><br>My name is <span class='bold'><a class='alink'>Muggalla Rahul</a>.</span><br><br>I am a Jnr AI Developer at <span class='bold'>Codegnan IT Solutions Pvt Ltd 👨🏻‍💻</span><br><br>I am eager to hear about potential career opportunities, so I would be pleased to chat about job openings in the engineering sphere.<br><br>Send <span class='bold'>'help'</span> to know more about me.<br>");
            }, 2000);
            break;
        case "help":
            sendTextMessage("<span class='sk'>Send Keyword to get what you want to know about me...<br>e.g<br><span class='bold'>'skills'</span> - to know my skills<br><span class='bold'>'resume'</span> - to get my resume<br><span class='bold'>'education'</span> - to get my education details<br><span class='bold'>'experience'</span> - to get my experience details<br><span class='bold'>'profile'</span> - to get my profile card<br><span class='bold'>'address'</span> - to get my address<br><span class='bold'>'contact'</span> - to get ways to connect with me<br><span class='bold'>'projects'</span> - to get details of my projects<br><span class='bold'>'clear'</span> - to clear conversation<br><span class='bold'>'about'</span> - to know about this site</span>");
            break;
        case "resume":
            sendTextMessage(resumeString);
            break;
        case "skills":
            sendTextMessage("<span class='sk'>My Tech Stack : <br><br>I can comfortably write code in following LANGUAGES :<br><span class='bold'>Python<br>Java<br>C<br>C...</span><br><br>I've experience with following HOSTING / SaaS :<span class='bold'><br>AWS<br>Heroku<br>Netlify<br>PythonAnywhere...<br></span><br><br>I've experience with following DATABASES :<span class='bold'><br>MYSql<br>MongoDB...<br></span><br><br>I've experience with following DESIGN :<span class='bold'><br>Adobe XD<br>Figma<br>Canva...<br></span><br><br>I've experience with following AI :<span class='bold'><br>Numpy<br>Pandas<br>Matplotlib / Seaborn / Plotly<br>Scikit-Learn<br>Scipy<br>Tensorflow / Keras<br>PyTorch<br>NLTK / Spacy<br>Hugging Face<br>LangChain<br>OpenAI<br>CV2 / Pydicom<br>PySpark...<br><br></span><br><br>I've experience with following OTHERS :<span class='bold'><br>Flask<br>Git<br>Power BI<br>Linux<br>Notion<br>Trello...<br></span><br><br>Favourite IDE : VSCode</span>");
            break;

        case "education":
            sendTextMessage("I have completed by Undergraduation in B.Sc Computer Science with Cognitive Systems (CSCS) from PB Siddhartha College<br>Passing Year : 2023<br><br>I have completed my Intermediate from Sri Bhavishya Junior College<br>Passing Year : 2020<br><br>I have completed my Secondary school from NSM Public School known as NSM<br>Passing Year : 2018");
            break;

        case "experience":
            sendTextMessage("<b>Full-Stack Developer Intern</b><br>Blackbucks Engineers Pvt Ltd<br>May 2022 – Jun 2022<br>• Full Stack Developer with a team of 4.<br>• I'm the developer of the project.<br>• Delivered full stack project Gainfolio in 2 weeks.<br><br><b>Data Science Intern</b><br>Blackbucks Engineers Pvt Ltd<br>Jul 2022 – July 2023<br>• I worked with the core development team of Blackbucks in the development of TapTap Blackbucks project.<br>• I have trainedg interns of Blackbucks on AI/ML and Full Stack domain.<br><br><b>AI Developer Intern</b><br>Codegnan IT Solutions<br>Dec 2022 – May 2023<br>• I work on different problem statements daily<br>• Developed various projects in AI/ML Domain<br>• Junior Trainer<br><br><b>AI/ML Engineer Intern</b><br>Myna Solutions<br>July 2023 – October 2023<br>• Implementing a robust NLP model that enabling the extraction of meaningful insights from raw data.<br><br><b>Jnr AI Developer</b><br>Codegnan IT Solutions<br>June 2023 – Present<br>• I work on developing Chatbots and other LLM Models to the organisation<br>• Developed various projects in AI/ML Domain<br>• Senior Trainer<br><br>");
            break;

        case "address":
            sendTextMessage(addressString);
            break;
        case "clear":
            clearChat();
            break;
        case "about":
            sendTextMessage("I'm a Smart Working and Enthusiastic Developer looking for opportunities. Pursued skills like Python, AI, Data Science, Machine Learning, etc. I always thought my dream was to be a Professional Developer. I have built few projects on my personal interest, you can check them in my GitHub Repositories. I have done certifications from Universities like Harvard University, University of Helsinki, etc. and from Organizations like Google, Microsoft, AWS, IBM, etc. I'm a Versatilist and easily adapt to different hats (Full Stack Web Developer 🌐, App Developer 📱, ML Engineer 🤖 or beginner level Designer 🎨) depending on what the project requires. I love exploring new tech stack 💻 and leveraging them to build cool stuffs 🛠️. <br><br>🌍  I'm based in Vijayawada, Andhra Pradesh, India<br>🤝  I'm open to collaborating on Open Source Machine Learning Community<br>🧠  I'm learning AI / ML, Data Science, Flutter, Blockchain, IOT, DevOps, Big Data,....<br>⚡  I'm secretly Elon Musk...🤫 but don't tell anyone<br><br>👨🏻‍💻 Designed and Developed by <a class='alink' target='_blank' href='#'><span class='bold'>Muggalla Rahul</a> with ❤️</span>");
            break;
        case "contact":
            sendTextMessage(contactString);
            break;
        case "projects":
            sendTextMessage("You want to check my projects? Then just jump into my Github Account.<br><br><div class='social'><a target='_blank' href='https://github.com/rahulmuggalla'> <div class='socialItem'><img class='socialItemI' src='images/github.svg' alt=''></div> </a></div>");
            break;
        case "profile":
            sendTextMessage("Here's my Profile Card : <br><br> <a target='_blank' href='https://flowcv.me/muggalla-rahul'>Muggalla Rahul");
            break;
        case "terminal":
            sendTextMessage("Under Development...");
            break;
        case "new":
            sendTextMessage(addressString);
            break;
        default:
            setTimeout(() => {
                sendTextMessage("Hey I couldn't catch you...😢<br>Send 'help' to know more about usage.");
            }, 2000);
            break;
    }



}

function clearChat() {
    document.getElementById("listUL").innerHTML = "";
    waitAndResponce('intro');
}



function sendTextMessage(textToSend) {
    setTimeout(setLastSeen, 1000);
    var date = new Date();
    var myLI = document.createElement("li");
    var myDiv = document.createElement("div");
    var greendiv = document.createElement("div");
    var dateLabel = document.createElement("label");
    dateLabel.setAttribute("id", "sentlabel");
    dateLabel.id = "sentlabel";
    dateLabel.innerText = date.getHours() + ":" + date.getMinutes();
    myDiv.setAttribute("class", "received");
    greendiv.setAttribute("class", "grey");
    greendiv.innerHTML = textToSend;
    myDiv.appendChild(greendiv);
    myLI.appendChild(myDiv);
    greendiv.appendChild(dateLabel);
    document.getElementById("listUL").appendChild(myLI);
    var s = document.getElementById("chatting");
    s.scrollTop = s.scrollHeight;
    playSound();
}


function sendResponse() {
    setTimeout(setLastSeen, 1000);
    var date = new Date();
    var myLI = document.createElement("li");
    var myDiv = document.createElement("div");
    var greendiv = document.createElement("div");
    var dateLabel = document.createElement("label");
    dateLabel.innerText = date.getHours() + ":" + date.getMinutes();
    myDiv.setAttribute("class", "received");
    greendiv.setAttribute("class", "grey");
    dateLabel.setAttribute("class", "dateLabel");
    greendiv.innerText = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ";
    myDiv.appendChild(greendiv);
    myLI.appendChild(myDiv);
    greendiv.appendChild(dateLabel);
    document.getElementById("listUL").appendChild(myLI);
    var s = document.getElementById("chatting");
    s.scrollTop = s.scrollHeight;
    playSound();
}

function playSound() {
    audio.play();
}
